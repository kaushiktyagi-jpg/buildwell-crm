
let customers=[]
let dispatch=[]
let bills=[]

function login(){
let u=document.getElementById('user').value
let p=document.getElementById('pass').value
if(u==='admin'&&p==='Kashi@123'){
document.getElementById('loginBox').style.display='none'
document.getElementById('app').classList.remove('hidden')
}else alert('Wrong Login')
}

function logout(){location.reload()}

function addCustomer(){
customers.push({name:cname.value,phone:cphone.value})
render()
}

function addDispatch(){
dispatch.push({v:dvehicle.value,s:dsite.value})
render()
}

function addBill(){
bills.push({n:bname.value,a:bamt.value})
render()
}

function render(){
document.getElementById('clist').innerHTML=customers.map(c=>`<p>${c.name} ${c.phone}</p>`).join('')
document.getElementById('dlist').innerHTML=dispatch.map(d=>`<p>${d.v} ${d.s}</p>`).join('')
document.getElementById('blist').innerHTML=bills.map(b=>`<p>${b.n} ₹${b.a}</p>`).join('')
}
